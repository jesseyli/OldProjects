package trip;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

/** Initial class for the 'trip' program.
 *  @author D. Hsu
 */
public final class Main {

    /** Entry point for the CS61B trip program.  ARGS may contain options
     *  and targets:
     *      [ -m MAP ] [ -o OUT ] [ REQUEST ]
     *  where MAP (default Map) contains the map data, OUT (default standard
     *  output) takes the result, and REQUEST (default standard input) contains
     *  the locations along the requested trip.
     */
    public static void main(String... args) {
        String mapFileName;
        String outFileName;
        String requestFileName;

        mapFileName = "Map";
        outFileName = requestFileName = null;

        int a;
        for (a = 0; a < args.length; a += 1) {
            if (args[a].equals("-m")) {
                a += 1;
                if (a == args.length) {
                    usage();
                } else {
                    mapFileName = args[a];
                }
            } else if (args[a].equals("-o")) {
                a += 1;
                if (a == args.length) {
                    usage();
                } else {
                    outFileName = args[a];
                }
            } else if (args[a].startsWith("-")) {
                usage();
            } else {
                break;
            }
        }

        if (a == args.length - 1) {
            requestFileName = args[a];
        } else if (a > args.length) {
            usage();
        }

        if (requestFileName != null) {
            try {
                System.setIn(new FileInputStream(requestFileName));
            } catch  (FileNotFoundException e) {
                System.err.printf("Could not open %s.%n", requestFileName);
                System.exit(1);
            }
        }

        if (outFileName != null) {
            try {
                System.setOut(new PrintStream(new FileOutputStream(outFileName),
                                              true));
            } catch  (FileNotFoundException e) {
                System.err.printf("Could not open %s for writing.%n",
                                  outFileName);
                System.exit(1);
            }
        }

        trip(mapFileName);
    }

    /** Print a trip for the request on the standard input to the standard
     *  output, using the map data in MAPFILENAME.
     */
    private static void trip(String mapFileName) {
        Scanner map;
        try {
            map = new Scanner(new File(mapFileName));
        } catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
            return;
        }

        List<Location> locations = new ArrayList<Location>();
        List<Distance> distances = new ArrayList<Distance>();

        try {
            int k = 1;
            while (map.hasNextLine()) {
                String line = map.nextLine();
                String[] words = line.trim().split("\\s+");
                if (words[0].equals("L")) {
                    locations.add(new Location(words[1],
                            Integer.parseInt(words[2]),
                            Integer.parseInt(words[3])));
                } else if (words[0].equals("R")) {
                    for (Location i : locations) {
                        if (i._place.equals(words[1])) {
                            break;
                        } else {
                            System.err.printf("Syntax error in line %d "
                                    + "of map file.\n", k);
                        }
                    }
                    for (Location i : locations) {
                        if (i._place.equals(words[5])) {
                            break;
                        } else {
                            System.err.printf("Syntax error in line %d "
                                    + "of map file.\n", k);
                        }
                    }
                    distances.add(new Distance(words[1], words[2],
                            Float.parseFloat(words[3]), words[4], words[5]));
                } else {
                    continue;
                }
                k++;
            }
        } catch (IllegalArgumentException | IndexOutOfBoundsException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }

        map.close();
    }

    /** Subclass Location. */
    static class Location {
        /** Locations contain a PLACE, as well as X and Y coordinates. */
        Location(String place, int x, int y) {
            _place = place;
            lat = x;
            lon = y;
        }

        /** String representing the location. */
        private String _place;
        /** X-coordinate representing latitude. */
        private int lat;
        /** Y-coordinate representing longitude. */
        private int lon;
    }

    /** Subclass Distance. */
    static class Distance {
        /** Distances contain a PLACE, a ROAD, a distance DIST,
         *  a polar direction D representing NS, EW, WE, SN, and
         *  a destination DEST. */
        Distance(String place, String road, float dist,
                String d, String dest) {
            _place = place;
            _road = road;
            _dist = dist;
            _d = d;
            _dest = dest;
        }

        /** The start of this Distance. */
        private String _place;
        /** The road this Distance measures. */
        private String _road;
        /** The numerical distance from place to dest. */
        private float _dist;
        /** The polar direction this road runs in. */
        private String _d;
        /** The destination of this Distance. */
        private String _dest;
    }

    /** Print a brief usage message and exit program abnormally. */
    private static void usage() {
        printHelpResource("graph/Usage.txt", new PrintWriter(System.out));
        System.exit(1);
    }

    /** Print the contents of the resource named NAME on OUT.
     *  NAME will typically be a file name based in one of the directories
     *  in the class path.  */
    static void printHelpResource(String name, PrintWriter out) {
        try {
            InputStream resource =
                Main.class.getClassLoader().getResourceAsStream(name);
            BufferedReader str =
                new BufferedReader(new InputStreamReader(resource));
            for (String s = str.readLine(); s != null; s = str.readLine())  {
                out.println(s);
            }
            str.close();
            out.flush();
        } catch (IOException excp) {
            out.printf("No help found.");
            out.flush();
        }
    }

}
