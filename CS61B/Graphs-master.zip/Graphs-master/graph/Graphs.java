package graph;

import java.util.List;
import java.util.TreeSet;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Comparator;
import java.util.ArrayList;

/** Assorted graph algorithms.
 *  @author D. Hsu
 */
public final class Graphs {

    /** Returns a path from V0 to V1 in G of minimum weight, according
     *  to the edge weighter EWEIGHTER.  VLABEL and ELABEL are the types of
     *  vertex and edge labels.  Assumes that H is a distance measure
     *  between vertices satisfying the two properties:
     *     a. H.dist(v, V1) <= shortest path from v to V1 for any v, and
     *     b. H.dist(v, w) <= H.dist(w, V1) + weight of edge (v, w), where
     *        v and w are any vertices in G.
     *
     *  As a side effect, uses VWEIGHTER to set the weight of vertex v
     *  to the weight of a minimal path from V0 to v, for each v in
     *  the returned path and for each v such that
     *       minimum path length from V0 to v + H.dist(v, V1)
     *              < minimum path length from V0 to V1.
     *  The final weights of other vertices are not defined.  If V1 is
     *  unreachable from V0, returns null and sets the minimum path weights of
     *  all reachable nodes.  The distance to a node unreachable from V0 is
     *  Double.POSITIVE_INFINITY. */
    public static <VLabel, ELabel> List<Graph<VLabel, ELabel>.Edge>
    shortestPath(Graph<VLabel, ELabel> G,
                 Graph<VLabel, ELabel>.Vertex V0,
                 final Graph<VLabel, ELabel>.Vertex V1,
                 final Distancer<? super VLabel> h,
                 final Weighter<? super VLabel> vweighter,
                 Weighting<? super ELabel> eweighter) {
        HashSet<Graph<VLabel, ELabel>.Vertex> closedset =
                new HashSet<Graph<VLabel, ELabel>.Vertex>();
        TreeSet<Graph<VLabel, ELabel>.Vertex> openset =
                new TreeSet<Graph<VLabel, ELabel>.Vertex>(
                        new Comparator<Graph<VLabel, ELabel>.Vertex>() {
                    public int compare(Graph<VLabel, ELabel>.Vertex v0,
                            Graph<VLabel, ELabel>.Vertex v1) {
                        return Double.compare(vweighter.weight(v0.getLabel())
                                + h.dist(v0.getLabel(), V1.getLabel()),
                                vweighter.weight(v1.getLabel())
                                + h.dist(v1.getLabel(), V1.getLabel()));
                    }
                });
        HashMap<Graph<VLabel, ELabel>.Vertex,
        Graph<VLabel, ELabel>.Vertex> from =
                new HashMap<Graph<VLabel, ELabel>.Vertex,
                Graph<VLabel, ELabel>.Vertex>();
        vweighter.setWeight(V0.getLabel(), (double) 0.0);
        openset.add(V0);

        while (!openset.isEmpty()) {
            Graph<VLabel, ELabel>.Vertex curr = openset.pollFirst();
            if (curr == V1) {
                return reconstruct(G, from, V1);
            }
            closedset.add(curr);
            for (Graph<VLabel, ELabel>.Vertex n : G.neighbors(curr)) {
                Graph<VLabel, ELabel>.Edge edge = null;
                for (Graph<VLabel, ELabel>.Edge e : G.edges()){
                    if (e.getV(n) == curr) {
                        edge = e;
                    }
                }
                double g_score = vweighter.weight(curr.getLabel())
                        + eweighter.weight(edge.getLabel());
                double f_score = g_score + h.dist(n.getLabel(), V1.getLabel());
                if (closedset.contains(n)
                        && f_score >= vweighter.weight(n.getLabel())
                        + h.dist(n.getLabel(), V1.getLabel())) {
                    continue;
                }
                if (!openset.contains(n)
                        || f_score < vweighter.weight(n.getLabel())
                        + h.dist(n.getLabel(), V1.getLabel())) {
                    from.put(n, curr);
                    vweighter.setWeight(n.getLabel(), g_score);
                    if (!openset.contains(n)) {
                        openset.add(n);
                    }
                }
            }
        }
        return null;
    }

    /** Returns a path from V0 to V1 in G of minimum weight, according
     *  to the weights of its edge labels.  VLABEL and ELABEL are the types of
     *  vertex and edge labels.  Assumes that H is a distance measure
     *  between vertices satisfying the two properties:
     *     a. H.dist(v, V1) <= shortest path from v to V1 for any v, and
     *     b. H.dist(v, w) <= H.dist(w, V1) + weight of edge (v, w), where
     *        v and w are any vertices in G.
     *
     *  As a side effect, sets the weight of vertex v to the weight of
     *  a minimal path from V0 to v, for each v in the returned path
     *  and for each v such that
     *       minimum path length from V0 to v + H.dist(v, V1)
     *           < minimum path length from V0 to V1.
     *  The final weights of other vertices are not defined.
     *
     *  This function has the same effect as the 6-argument version of
     *  shortestPath, but uses the .weight and .setWeight methods of
     *  the edges and vertices themselves to determine and set
     *  weights. If V1 is unreachable from V0, returns null and sets
     *  the minimum path weights of all reachable nodes.  The distance
     *  to a node unreachable from V0 is Double.POSITIVE_INFINITY. */
    public static
    <VLabel extends Weightable, ELabel extends Weighted>
    List<Graph<VLabel, ELabel>.Edge>
    shortestPath(Graph<VLabel, ELabel> G,
                 final Graph<VLabel, ELabel>.Vertex V0,
                 final Graph<VLabel, ELabel>.Vertex V1,
                 final Distancer<? super VLabel> h) {
        HashSet<Graph<VLabel, ELabel>.Vertex> closedset =
                new HashSet<Graph<VLabel, ELabel>.Vertex>();
        TreeSet<Graph<VLabel, ELabel>.Vertex> openset =
                new TreeSet<Graph<VLabel, ELabel>.Vertex>(
                        new Comparator<Graph<VLabel, ELabel>.Vertex>() {
                    public int compare(Graph<VLabel, ELabel>.Vertex v0,
                            Graph<VLabel, ELabel>.Vertex v1) {
                        return Double.compare(v0.getLabel().weight()
                                + h.dist(v0.getLabel(), V1.getLabel()),
                                v1.getLabel().weight()
                                + h.dist(v1.getLabel(), V1.getLabel()));
                    }
                });
        HashMap<Graph<VLabel, ELabel>.Vertex,
        Graph<VLabel, ELabel>.Vertex> from =
                new HashMap<Graph<VLabel, ELabel>.Vertex,
                Graph<VLabel, ELabel>.Vertex>();
        V0.getLabel().setWeight(0.0);
        openset.add(V0);

        while (!openset.isEmpty()) {
            Graph<VLabel, ELabel>.Vertex curr = openset.pollFirst();
            if (curr == V1) {
                return reconstruct(G, from, V1);
            }
            closedset.add(curr);
            for (Graph<VLabel, ELabel>.Vertex n : G.neighbors(curr)) {
                Graph<VLabel, ELabel>.Edge edge = null;
                for (Graph<VLabel, ELabel>.Edge e : G.edges()){
                    if (e.getV(n) == curr) {
                        edge = e;
                    }
                }
                Double g_score = curr.getLabel().weight()
                        + edge.getLabel().weight();
                Double f_score = g_score + h.dist(n.getLabel(), V1.getLabel());
                if (closedset.contains(n)
                        && f_score >= n.getLabel().weight()) {
                    continue;
                }
                if (!openset.contains(n)
                        || f_score < n.getLabel().weight()) {
                    from.put(n, curr);
                    n.getLabel().setWeight(g_score);
                    if (!openset.contains(n)) {
                        openset.add(n);
                    }
                }
            }
        }
        return null;
    }

    /** Helper method for A* search. Reconstructs the path to V1
     *  that the lowest f_score in FROM takes.
     */
    private static <VLabel, ELabel> List<Graph<VLabel, ELabel>.Edge>
    reconstruct(Graph<VLabel, ELabel> G,
            HashMap<Graph<VLabel, ELabel>.Vertex,
            Graph<VLabel, ELabel>.Vertex> from,
            Graph<VLabel, ELabel>.Vertex V1) {
        if (from.containsKey(V1)) {
            ArrayList<Graph<VLabel, ELabel>.Edge> result =
                    new ArrayList<Graph<VLabel, ELabel>.Edge>();
            Graph<VLabel, ELabel>.Vertex curr = from.get(V1);
            Graph<VLabel, ELabel>.Edge edge = null;
            for (Graph<VLabel, ELabel>.Edge e : G.edges()){
                if (e.getV(V1) == curr) {
                    edge = e;
                }
            }
            result.add(edge);
            result.addAll(reconstruct(G, from, curr));
            return result;
        }
        return null;
    }

    /** Returns a distancer whose dist method always returns 0. */
    public static final Distancer<Object> ZERO_DISTANCER =
        new Distancer<Object>() {
            @Override
            public double dist(Object v0, Object v1) {
                return 0.0;
            }
        };
}
