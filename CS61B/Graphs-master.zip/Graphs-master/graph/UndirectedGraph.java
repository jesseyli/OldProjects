package graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* Do not add or remove public or protected members, or modify the signatures of
 * any public methods.  You may add bodies to abstract methods, modify
 * existing bodies, or override inherited methods.  */

/** An undirected graph with vertices labeled with VLABEL and edges
 *  labeled with ELABEL.
 *  @author D. Hsu
 */
public class UndirectedGraph<VLabel, ELabel> extends Graph<VLabel, ELabel> {

    /** An empty graph. */
    public UndirectedGraph() {
    }

    @Override
    public boolean isDirected() {
        return false;
    }

    @Override
    public int outDegree(Vertex v) {
        return inDegree(v) + vertices.get(v).size();
    }

    @Override
    public boolean contains(Vertex u, Vertex v) {
        if (vertices.containsKey(u)) {
            List<Edge> uedges = vertices.get(u);
            for (Edge e : uedges) {
                if (e.getV0() == u && e.getV1() == v)
                    return true;
            }
            List<Edge> vedges = vertices.get(v);
            for (Edge e : vedges) {
                if (e.getV1() == u && e.getV0() == v)
                    return true;
            }
        }
        return false;
    }

    @Override
    public boolean contains(Vertex u, Vertex v, ELabel label) {
        if (vertices.containsKey(u)) {
            List<Edge> uedges = vertices.get(u);
            for (Edge e : uedges) {
                if ((e.getV0() == u && e.getV1() == v)
                        && e.getLabel().equals(label))
                    return true;
            }
            List<Edge> vedges = vertices.get(v);
            for (Edge e : vedges) {
                if ((e.getV1() == u && e.getV0() == v)
                    && e.getLabel().equals(label))
                    return true;
            }
        }
        return false;
    }

    @Override
    public Iteration<Vertex> successors(Vertex v) {
        List<Vertex> S = new ArrayList<Vertex>();
        Iteration<Edge> edges = edges();
        for (Edge e : edges) {
            if (e.getV0() == v) {
                S.add(e.getV1());
            } else if (e.getV1() == v) {
                S.add(e.getV0());
            }
        }
        return Iteration.iteration(S.iterator());
    }

    @Override
    public Iteration<Edge> outEdges(Vertex v) {
        List<Edge> result = new ArrayList<Edge>();
        Iterator<List<Edge>> iter = vertices.values().iterator();
        while (iter.hasNext()) {
            for (Edge e : iter.next()) {
                if (e.getV1() == v || e.getV0() == v) {
                    result.add(e);
                }
            }
        }
        return Iteration.iteration(result.iterator());
    }

}
