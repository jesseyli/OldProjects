package graph;

import org.junit.Test;

import ucb.junit.textui;
import graph.Graph.Vertex;
import graph.Graph.Edge;
import java.util.ArrayList;

import static org.junit.Assert.*;

/* You MAY add public @Test methods to this class.  You may also add
 * additional public classes containing "Testing" in their name. These
 * may not be part of your graph package per se (that is, it must be
 * possible to remove them and still have your package work). */

/** Unit tests for the graph package.
 *  @author D. Hsu
 */
public class Testing {

    /** Run all JUnit tests in the graph package. */
    public static void main(String[] ignored) {
        System.exit(textui.runClasses(graph.Testing.class));
    }

    @Test
    public void sizesTest() {
        Graph<String, String> g = new DirectedGraph<String, String>();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        Vertex C = g.add("C");
        Edge a = g.add(A, B, "a");
        Edge b = g.add(B, C, "b");
        Edge a1 = g.add(A, B, "a1");
        Edge n = g.add(A, C);
        assertEquals("Initial graph has edges", 4, g.edgeSize());
        assertEquals("Initial graph has vertices", 3, g.vertexSize());
        assertEquals("Vertex A should have 3 outgoing edges",
                3, g.outDegree(A));
        assertEquals("Vertex B should have 1 outgoing edge",
                1, g.outDegree(B));
        assertEquals("Vertex C should have 2 incoming edges",
                2, g.inDegree(C));
        assertTrue("Should contain a vertex from A to C", g.contains(A, C));
    }

    @Test
    public void removeTest() {
        Graph<String, String> g = new DirectedGraph<String, String>();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        Vertex C = g.add("C");
        Edge a = g.add(A, B, "a");
        Edge b = g.add(B, C, "b");
        Edge a1 = g.add(A, B);
        Edge a2 = g.add(A, B);
        Edge n = g.add(A, C);
        assertEquals("Vertex A should have 4 outgoing edges",
                4, g.outDegree(A));
        g.remove(a);
        assertEquals("Graph has edges", 4, g.edgeSize());
        assertEquals("Vertex A should have 3 outgoing edges",
                3, g.outDegree(A));
        g.remove(A, B);
        assertEquals("Graph has edges", 2, g.edgeSize());
        assertEquals("Vertex A should have 1 outgoing edges",
                1, g.outDegree(A));
        g.remove(C);
        assertEquals("Graph has vertices", 2, g.vertexSize());
        assertEquals("Graph has edges", 0, g.edgeSize());
    }

    @Test
    public void iteratorTest() {
        Graph<String, String> g = new DirectedGraph<String, String>();
        ArrayList<Vertex> verts = new ArrayList<Vertex>();
        ArrayList<Edge> edges = new ArrayList<Edge>();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        Vertex C = g.add("C");
        Vertex D = g.add("D");
        verts.add(A); verts.add(B); verts.add(C); verts.add(D);
        Edge d = g.add(A, D);
        Edge a = g.add(A, B, "a");
        Edge b = g.add(B, C, "b");
        Edge a1 = g.add(A, B);
        Edge n = g.add(A, C);
        Edge d1 = g.add(D, C);
        Edge a2 = g.add(A, A);
        Edge c2 = g.add(C, C);
        edges.add(a); edges.add(b); edges.add(a1); edges.add(n); edges.add(d);
        edges.add(d1); edges.add(a2); edges.add(c2);
        Iteration<Graph<String, String>.Vertex> vertices = g.vertices();
        for (Vertex v : vertices) {
            assertTrue("Iteration should contain added vertices",
                    verts.contains(v));
        }
        Iteration<Graph<String, String>.Edge> edge = g.edges(); 
        for (Edge e : edge) {
            assertTrue("Iteration should contain added edges",
                    edges.contains(e));
        }
        ArrayList<Vertex> success = new ArrayList<Vertex>();
        success.add(B); success.add(D); success.add(C); success.add(A);
        Iteration<Graph<String, String>.Vertex> asucc = g.successors(A);
        for (Vertex v : asucc) {
            assertTrue("Iteration should contain successors of A",
                    success.contains(v));
        }
        ArrayList<Vertex> preds = new ArrayList<Vertex>();
        preds.add(A); preds.add(D); preds.add(B); preds.add(C);
        Iteration<Graph<String, String>.Vertex> predecess = g.predecessors(C);
        for (Vertex v : predecess) {
            assertTrue("Iteration should contain predecessors of C",
                    preds.contains(v));
        }
        Iteration<Graph<String, String>.Edge> out = g.outEdges(A);
        ArrayList<Edge> outs = new ArrayList<Edge>();
        outs.add(d); outs.add(a); outs.add(a1); outs.add(n); outs.add(a2);
        for (Edge e : out) {
            assertTrue("Iteration should contain out edges of A",
                    outs.contains(e));
        }
        Iteration<Graph<String, String>.Edge> in = g.inEdges(A);
        ArrayList<Edge> ins = new ArrayList<Edge>();
        ins.add(a2);
        for (Edge e : in) {
            assertTrue("Iteration should contain out edges of A",
                    ins.contains(e));
        }
    }

    @Test
    public void orderTest() {
        Graph<String, String> g = new DirectedGraph<String, String>();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        Vertex C = g.add("C");
        Edge c = g.add(C, A, "c");
        Edge a1 = g.add(A, C, "a1");
        Edge b = g.add(B, C, "b");
        Edge a = g.add(A, B, "a");
        g.orderEdges(Graph.<String>naturalOrder());
        Iteration<Graph<String, String>.Edge> edges = g.edges();
        ArrayList<Graph<String, String>.Edge> e = new ArrayList();
        e.add(a); e.add(a1); e.add(b); e.add(c);
        int i = 0;
        for (Edge k : edges) {
            assertTrue("Call to edges() should be ordered",
                    k == e.get(i));
            i++;
        }
    }

    @Test
    public void undirectedTest() {
        Graph<String, String> g = new UndirectedGraph<String, String>();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        Vertex C = g.add("C");
        Edge c = g.add(C, A, "c");
        Edge a1 = g.add(A, C, "a1");
        Edge b = g.add(B, C, "b");
        Edge a = g.add(A, B, "a");
        assertEquals("C should have a degree of", 3, g.degree(C));
        assertTrue("There should be an edge from C to B", g.contains(C, B, "b"));
        assertTrue("There should be an edge from B to A", g.contains(B, A));
        ArrayList<Vertex> neighbors = new ArrayList<Vertex>();
        neighbors.add(A); neighbors.add(C);
        Iteration<Graph<String, String>.Vertex> nayyy = g.neighbors(B);
        for (Vertex e : nayyy) {
            assertTrue("A and C should be neighbors to B", neighbors.contains(e));
        }
        ArrayList<Edge> edges = new ArrayList<Edge>();
        edges.add(a); edges.add(c); edges.add(a1);
        Iteration<Graph<String, String>.Edge> edgy = g.edges(A);
        for (Edge e : edgy) {
            assertTrue("a, c, and a1 should be edges to A", edges.contains(e));
        }
    }

    @Test
    public void emptyGraph() {
        DirectedGraph g = new DirectedGraph();
        assertEquals("Initial graph has vertices", 0, g.vertexSize());
        assertEquals("Initial graph has edges", 0, g.edgeSize());
    }

    @Test
    public void traverseTest() {
        System.out.println("Ordered traversal test.");
        DirectedGraph<Integer, Integer> g =
                new DirectedGraph<Integer, Integer>();
        Vertex A = g.add(1);
        Vertex B = g.add(4);
        Vertex C = g.add(3);
        Vertex D = g.add(2);
        Vertex E = g.add(6);
        Vertex F = g.add(5);
        Edge one = g.add(A, B, 1);
        Edge two = g.add(A, C, 2);
        Edge three = g.add(A, D, 3);
        Edge four = g.add(D, E, 4);
        Edge five = g.add(D, F, 5);

        Traversal<Integer, Integer> T =
                new Traversal<Integer, Integer>() {
            protected void preVisit(Graph<Integer, Integer>.Edge e,
                            Graph<Integer, Integer>.Vertex v0) {
                System.out.println("pr" + v0);
            }
            protected void visit(Graph<Integer, Integer>.Vertex v) {
                System.out.println("v" + v);
            }
            protected void postVisit(Graph<Integer, Integer>.Vertex v) {
                System.out.println("pv" + v);
            }
        };

        T.traverse(g, A, Graph.<Integer>naturalOrder());
        System.out.println("\n");
    }

    @Test
    public void depthFirstTest() {
        System.out.println("Depth-first traversal test.");
        DirectedGraph g = new DirectedGraph();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        final Vertex C = g.add("C");
        Vertex D = g.add("D");
        Vertex E = g.add("E");
        final Vertex F = g.add("F");
        Edge one = g.add(A, B, 1);
        Edge two = g.add(A, C, 2);
        Edge three = g.add(A, D, 3);
        Edge four = g.add(D, E, 4);
        Edge five = g.add(D, F, 5);

        Traversal<String, Integer> T =
                new Traversal<String, Integer>() {
            protected void preVisit(Graph<String, Integer>.Edge e,
                            Graph<String, Integer>.Vertex v0) {
                System.out.println("pr" + v0);
            }
            protected void visit(Graph<String, Integer>.Vertex v) {
                if (v == F || v == C) {
                    throw new RejectException();
                }
                System.out.println("v" + v);
            }
            protected void postVisit(Graph<String, Integer>.Vertex v) {
                System.out.println("pv" + v);
            }
        };

        T.depthFirstTraverse(g, A);
        System.out.println("\n");
    }

    @Test
    public void rejectTest() {
        System.out.println("Rejection of first node test.");
        DirectedGraph g = new DirectedGraph();
        Vertex A = g.add("A");
        Traversal<String, Integer> T =
                new Traversal<String, Integer>() {
            protected void preVisit(Graph<String, Integer>.Edge e,
                            Graph<String, Integer>.Vertex v0) {
                System.out.println("pr" + v0);
            }
            protected void visit(Graph<String, Integer>.Vertex v) {
                if (v.getLabel().equals("A")) {
                    throw new RejectException();
                }
                System.out.println("v" + v);
            }
            protected void postVisit(Graph<String, Integer>.Vertex v) {
                System.out.println("pv" + v);
            }
        };
        T.depthFirstTraverse(g, A);
    }

    @Test
    public void breadthFirstTest() {
        System.out.println("Breadth-first traversal test.");
        DirectedGraph g = new DirectedGraph();
        Vertex A = g.add("A");
        Vertex B = g.add("B");
        Vertex C = g.add("C");
        Vertex D = g.add("D");
        Vertex E = g.add("E");
        Vertex F = g.add("F");
        Vertex G = g.add("G");
        Edge one = g.add(A, B, 1);
        Edge two = g.add(A, C, 2);
        Edge three = g.add(A, D, 3);
        Edge four = g.add(D, E, 4);
        Edge five = g.add(D, F, 5);
        Edge six = g.add(C, G, 6);

        Traversal<String, Integer> T =
                new Traversal<String, Integer>() {
            protected void preVisit(Graph<String, Integer>.Edge e,
                            Graph<String, Integer>.Vertex v0) {
                System.out.println("pr" + v0);
            }
            protected void visit(Graph<String, Integer>.Vertex v) {
                if (v.getLabel().equals("C")) {
                    throw new RejectException();
                }
                System.out.println("v" + v);
            }
            protected void postVisit(Graph<String, Integer>.Vertex v) {
                System.out.println("pv" + v);
            }
        };

        T.breadthFirstTraverse(g, A);
        System.out.println("\n");
    }

}
