package graph;

import java.util.ArrayDeque;
import java.util.Vector;
import java.util.Comparator;
import java.util.Collections;
import java.util.Stack;

/** Implements a generalized traversal of a graph.  At any given time,
 *  there is a particular set of untraversed vertices---the "fringe."
 *  Traversal consists of repeatedly removing an untraversed vertex
 *  from the fringe, visting it, and then adding its untraversed
 *  successors to the fringe.  The client can dictate an ordering on
 *  the fringe, determining which item is next removed, by which kind
 *  of traversal is requested.
 *     + A depth-first traversal treats the fringe as a list, and adds
 *       and removes vertices at one end.  It also revisits the node
 *       itself after traversing all successors by calling the
 *       postVisit method on it.
 *     + A breadth-first traversal treats the fringe as a list, and adds
 *       and removes vertices at different ends.  It also revisits the node
 *       itself after traversing all successors as for depth-first
 *       traversals.
 *     + A general traversal treats the fringe as an ordered set, as
 *       determined by a Comparator argument.  There is no postVisit
 *       for this type of traversal.
 *  As vertices are added to the fringe, the traversal calls a
 *  preVisit method on the vertex.
 *
 *  Generally, the client will extend Traversal, overriding the visit,
 *  preVisit, and postVisit methods, as desired (by default, they do nothing).
 *  Any of these methods may throw StopException to halt the traversal
 *  (temporarily, if desired).  The preVisit method may throw a
 *  RejectException to prevent a vertex from being added to the
 *  fringe, and the visit method may throw a RejectException to
 *  prevent its successors from being added to the fringe.
 *  @author D. Hsu
 */
public class Traversal<VLabel, ELabel> {

    /** Perform a traversal of G over all vertices reachable from V.
     *  ORDER determines the ordering in which the fringe of
     *  untraversed vertices is visited.  The effect of specifying an
     *  ORDER whose results change as a result of modifications made during the
     *  traversal is undefined. */
    public void traverse(Graph<VLabel, ELabel> G,
                         Graph<VLabel, ELabel>.Vertex v,
                         Comparator<VLabel> order) {
        final Comparator<VLabel> comp = order;
        Comparator<Graph<VLabel, ELabel>.Vertex> ordering =
                new Comparator<Graph<VLabel, ELabel>.Vertex>() {
            public int compare(Graph<VLabel, ELabel>.Vertex v0,
                    Graph<VLabel, ELabel>.Vertex v1) {
                return comp.compare(v0.getLabel(), v1.getLabel());
            }
        };

        Vector<Graph<VLabel, ELabel>.Vertex> fringe =
                new Vector<Graph<VLabel, ELabel>.Vertex>();
        Vector<Graph<VLabel, ELabel>.Vertex> traversed = _traversed;
        resetFields();
        fringe.add(v);

        while (!fringe.isEmpty()) {
            Graph<VLabel, ELabel>.Vertex vertex = fringe.remove(0);
            try {
            if (!traversed.contains(vertex)) {
                try {
                    visit(vertex);
                } catch (RejectException e) {
                    continue;
                }
                traversed.add(vertex);
                for (Graph<VLabel, ELabel>.Edge e : G.outEdges(vertex)) {
                    if (!traversed.contains(e.getV(vertex))) {
                        try {
                            preVisit(e, e.getV(vertex));
                        } catch (RejectException ee) {
                            continue;
                        } catch (StopException r) {
                            lastTraversal = "r";
                            _traversed = traversed;
                            _finalVertex = e.getV(vertex);
                            _finalEdge = e;
                            _graph = G;
                            _order = order;
                        }
                        fringe.add(e.getV(vertex));
                    }
                }
                Collections.sort(fringe, ordering);
            }
            } catch (StopException r) {
                lastTraversal = "r";
                _traversed = traversed;
                _finalVertex = vertex;
                _graph = G;
                _order = order;
            } catch (RejectException e) {
                continue;
            }
        }
    }

    /** Performs a depth-first traversal of G over all vertices
     *  reachable from V.  That is, the fringe is a sequence and
     *  vertices are added to it or removed from it at one end in
     *  an undefined order.  After the traversal of all successors of
     *  a node is complete, the node itself is revisited by calling
     *  the postVisit method on it. */
    public void depthFirstTraverse(Graph<VLabel, ELabel> G,
                                   Graph<VLabel, ELabel>.Vertex v) {
        Stack<Graph<VLabel, ELabel>.Vertex> fringe =
                new Stack<Graph<VLabel, ELabel>.Vertex>();
        Vector<Graph<VLabel, ELabel>.Vertex> traversed = _traversed;
        Vector<Graph<VLabel, ELabel>.Vertex> postvisited =
                new Vector<Graph<VLabel, ELabel>.Vertex>();
        resetFields(); fringe.add(v);
        outerloop:
        while (!fringe.empty()) {
            Graph<VLabel, ELabel>.Vertex vertex = fringe.peek();
            try {
            if (!traversed.contains(vertex)) {
                traversed.add(vertex);
                visit(vertex);
                Vector<Graph<VLabel, ELabel>.Edge> reverse =
                        new Vector<Graph<VLabel, ELabel>.Edge>();
                for (Graph<VLabel, ELabel>.Edge e : G.outEdges(vertex)) {
                    Graph<VLabel, ELabel>.Vertex vert = e.getV(vertex);
                    if (!traversed.contains(vert)) {
                        try {
                            preVisit(e, vert);
                        } catch (StopException r) {
                            lastTraversal = "d";
                            _traversed = traversed;
                            _finalVertex = vert;
                            _finalEdge = e;
                            _graph = G;
                        } catch (RejectException ee) {
                            continue;
                        }
                        reverse.add(e);
                    }
                }
                Collections.reverse(reverse);
                for (Graph<VLabel, ELabel>.Edge e : reverse) {
                    fringe.push(e.getV(vertex));
                }
            }
            if (!postvisited.contains(vertex)
                    && traversed.contains(vertex)) {
                for (Graph<VLabel, ELabel>.Edge e : G.outEdges(vertex)) {
                    if (!traversed.contains(e.getV(vertex))) {
                        continue outerloop;
                    }
                }
                vertex = fringe.pop();
                postVisit(vertex);
                postvisited.add(vertex);
            }
            } catch (StopException r) {
                lastTraversal = "d";
                _traversed = traversed;
                _finalVertex = vertex;
                _graph = G;
            } catch (RejectException e) {
                fringe.pop();
                postvisited.add(vertex);
                continue;
            }
        }
    }

    /** Performs a breadth-first traversal of G over all vertices
     *  reachable from V.  That is, the fringe is a sequence and
     *  vertices are added to it at one end and removed from it at the
     *  other in an undefined order.  After the traversal of all successors of
     *  a node is complete, the node itself is revisited by calling
     *  the postVisit method on it. */
    public void breadthFirstTraverse(Graph<VLabel, ELabel> G,
                                     Graph<VLabel, ELabel>.Vertex v) {
        ArrayDeque<Graph<VLabel, ELabel>.Vertex> fringe =
                new ArrayDeque<Graph<VLabel, ELabel>.Vertex>();
        Vector<Graph<VLabel, ELabel>.Vertex> traversed = _traversed;
        Vector<Graph<VLabel, ELabel>.Vertex> postvisited =
                new Vector<Graph<VLabel, ELabel>.Vertex>();
        resetFields();
        fringe.add(v);
        outerloop:
        while (!fringe.isEmpty()) {
            Graph<VLabel, ELabel>.Vertex vertex = fringe.removeFirst();
            try {
            if (!traversed.contains(vertex)) {
                traversed.add(vertex);
                try {
                    visit(vertex);
                } catch (RejectException e) {
                    continue;
                }
                for (Graph<VLabel, ELabel>.Edge e : G.outEdges(vertex)) {
                    Graph<VLabel, ELabel>.Vertex succ = e.getV(vertex);
                    if (!traversed.contains(succ)) {
                        try {
                            preVisit(e, succ);
                        } catch (RejectException ee) {
                            continue;
                        } catch (StopException r) {
                            lastTraversal = "b";
                            _traversed = traversed;
                            _finalVertex = succ;
                            _finalEdge = e;
                            _graph = G;
                        }
                        fringe.add(succ);
                    }
                }
                fringe.add(vertex);
            } else if (!postvisited.contains(vertex)
                    && traversed.contains(vertex)) {
                for (Graph<VLabel, ELabel>.Edge e : G.outEdges(vertex)) {
                    if (!traversed.contains(e.getV(vertex))) {
                        continue outerloop;
                    }
                }
                postvisited.add(vertex);
                try {
                    postVisit(vertex);
                } catch (RejectException eee) {
                }
            }
            } catch (StopException r) {
                lastTraversal = "b";
                _traversed = traversed;
                _finalVertex = vertex;
                _graph = G;
            }
        }
    }

    /** Continue the previous traversal starting from V.
     *  Continuing a traversal means that we do not traverse
     *  vertices that have been traversed previously. */
    public void continueTraversing(Graph<VLabel, ELabel>.Vertex v) {
        if (lastTraversal.equals("r")) {
            traverse(_graph, v, _order);
        } else if (lastTraversal.equals("d")) {
            depthFirstTraverse(_graph, v);
        } else if (lastTraversal.equals("B")) {
            breadthFirstTraverse(_graph, v);
        }
    }

    /** If the traversal ends prematurely, returns the Vertex argument to
     *  preVisit, visit, or postVisit that caused a Visit routine to
     *  return false.  Otherwise, returns null. */
    public Graph<VLabel, ELabel>.Vertex finalVertex() {
        return _finalVertex;
    }

    /** If the traversal ends prematurely, returns the Edge argument to
     *  preVisit that caused a Visit routine to return false. If it was not
     *  an edge that caused termination, returns null. */
    public Graph<VLabel, ELabel>.Edge finalEdge() {
        return _finalEdge;
    }

    /** Returns the last graph argument to a traverse routine, or null if none
     *  of these methods have been called. */
    protected Graph<VLabel, ELabel> theGraph() {
        return _graph;
    }

    /** Method to be called when adding the node at the other end of E from V0
     *  to the fringe. If this routine throws a StopException,
     *  the traversal ends.  If it throws a RejectException, the edge
     *  E is not traversed. The default does nothing.
     */
    protected void preVisit(Graph<VLabel, ELabel>.Edge e,
                            Graph<VLabel, ELabel>.Vertex v0) {
    }

    /** Method to be called when visiting vertex V.  If this routine throws
     *  a StopException, the traversal ends.  If it throws a RejectException,
     *  successors of V do not get visited from V. The default does nothing. */
    protected void visit(Graph<VLabel, ELabel>.Vertex v) {
    }

    /** Method to be called immediately after finishing the traversal
     *  of successors of vertex V in pre- and post-order traversals.
     *  If this routine throws a StopException, the traversal ends.
     *  Throwing a RejectException has no effect. The default does nothing.
     */
    protected void postVisit(Graph<VLabel, ELabel>.Vertex v) {
    }

    /** Resets all fields relating to continuing a traversal. */
    private void resetFields() {
        lastTraversal = null;
        _traversed = new Vector<Graph<VLabel, ELabel>.Vertex>();
        _finalVertex = null;
        _finalEdge = null;
        _graph = null;
        _order = null;
    }

    /** The Vertex (if any) that terminated the last traversal. */
    protected Graph<VLabel, ELabel>.Vertex _finalVertex;
    /** The Edge (if any) that terminated the last traversal. */
    protected Graph<VLabel, ELabel>.Edge _finalEdge;
    /** The last graph traversed. */
    protected Graph<VLabel, ELabel> _graph;
    /** The traversal last stopped by a StopException. */
    private String lastTraversal;
    /** A list of vertices that were marked on the previously
     *  stopped traversal. */
    private Vector<Graph<VLabel, ELabel>.Vertex> _traversed = 
            new Vector<Graph<VLabel, ELabel>.Vertex>();
    /** Comparator used by regular traversal. */
    private Comparator<VLabel> _order;

}
