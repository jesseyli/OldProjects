package graph;

import java.util.ArrayList;
import java.util.List;

/** Assorted graph algorithms.
 *  @author Jesse Li
 */
public final class Graphs {

    /* A* Search Algorithms */

    /** Returns a path from V0 to V1 in G of minimum weight, according
     *  to the edge weighter EWEIGHTER.  VLABEL and ELABEL are the types of
     *  vertex and edge labels.  Assumes that H is a distance measure
     *  between vertices satisfying the two properties:
     *     a. H.dist(v, V1) <= shortest path from v to V1 for any v, and
     *     b. H.dist(v, w) <= H.dist(w, V1) + weight of edge (v, w), where
     *        v and w are any vertices in G.
     *
     *  As a side effect, uses VWEIGHTER to set the weight of vertex v
     *  to the weight of a minimal path from V0 to v, for each v in
     *  the returned path and for each v such that
     *       minimum path length from V0 to v + H.dist(v, V1)
     *              < minimum path length from V0 to V1.
     *  The final weights of other vertices are not defined.  If V1 is
     *  unreachable from V0, returns null and sets the minimum path weights of
     *  all reachable nodes.  The distance to a node unreachable from V0 is
     *  Double.POSITIVE_INFINITY. */
    public static <VLabel, ELabel> List<Graph<VLabel, ELabel>.Edge>
    shortestPath(Graph<VLabel, ELabel> G,
                 Graph<VLabel, ELabel>.Vertex V0,
                 Graph<VLabel, ELabel>.Vertex V1,
                 Distancer<? super VLabel> h,
                 Weighter<? super VLabel> vweighter,
                 Weighting<? super ELabel> eweighter) {
        ArrayList<Graph<VLabel, ELabel>.Edge> finalPath =
                new ArrayList<Graph<VLabel, ELabel>.Edge>();
        ArrayList<Graph<VLabel, ELabel>.Vertex> toCheck =
                new ArrayList<Graph<VLabel, ELabel>.Vertex>();
        ArrayList<Graph<VLabel, ELabel>.Vertex> visited =
                new ArrayList<Graph<VLabel, ELabel>.Vertex>();
        visited.add(V0);
        toCheck.add(V0);
        Graph<VLabel, ELabel>.Vertex currVertex = V0;
        vweighter.setWeight(currVertex.getLabel(), 0);
        /** for (Graph<VLabel, ELabel>.Vertex v: G.successors(V0)) {
            toCheck.add(v);
            vweighter.setWeight(v.getLabel(), vweighter.weight(V0.getLabel())
                    + h.dist(V0.getLabel(), v.getLabel()));
        } */
        while (!toCheck.isEmpty()) {
            currVertex = bestVertex(G, V1, h, vweighter, eweighter, toCheck);
            if (currVertex.equals(V1)) {
                return result;
            }
            toCheck.remove(currVertex);
            for (Graph<VLabel, ELabel>.Vertex v: G.successors(currVertex)) {
                toCheck.add(v);
            }
        }
        return null;
    }

    private static <VLabel, ELabel> Graph<VLabel, ELabel>.Vertex
    bestVertex(Graph<VLabel, ELabel> G, Graph<VLabel, ELabel>.Vertex V1,
                 Distancer<? super VLabel> h,
                 Weighter<? super VLabel> vweighter,
                 Weighting<? super ELabel> eweighter,
                 ArrayList<Graph<VLabel, ELabel>.Vertex> toCheck) {
        Graph<VLabel, ELabel>.Vertex smallest = toCheck.get(0);
        double minDistance = vweighter.weight(smallest.getLabel())
                + h.dist(smallest.getLabel(), V1.getLabel());
        for (Graph<VLabel, ELabel>.Vertex v: toCheck) {
            double nextDistance = vweighter.weight(v.getLabel())
                    + h.dist(v.getLabel(), V1.getLabel());
            if (nextDistance < minDistance) {
                smallest = v;
                minDistance = nextDistance;
            }
        }
        return smallest;
    }
/**
    function A*(start,goal)
    closedset := the empty set    // The set of nodes already evaluated.
    openset := {start}    // The set of tentative nodes to be evaluated, initially containing the start node
    came_from := the empty map    // The map of navigated nodes.

    g_score[start] := 0    // Cost from start along best known path.
    // Estimated total cost from start to goal through y.
    f_score[start] := g_score[start] + heuristic_cost_estimate(start, goal)
     
    while openset is not empty
        current := the node in openset having the lowest f_score[] value
        if current = goal
            return reconstruct_path(came_from, goal)
         
        remove current from openset
        add current to closedset
        for each neighbor in neighbor_nodes(current)
            tentative_g_score := g_score[current] + dist_between(current,neighbor)
            tentative_f_score := tentative_g_score + heuristic_cost_estimate(neighbor, goal)
            if neighbor in closedset and tentative_f_score >= f_score[neighbor]
                    continue

            if neighbor not in openset or tentative_f_score < f_score[neighbor] 
                came_from[neighbor] := current
                g_score[neighbor] := tentative_g_score
                f_score[neighbor] := tentative_f_score
                if neighbor not in openset
                    add neighbor to openset

    return failure
function reconstruct_path(came_from, current_node)
    if current_node in came_from
        p := reconstruct_path(came_from, came_from[current_node])
        return (p + current_node)
    else
        return current_node
*/
    
    /** Returns a path from V0 to V1 in G of minimum weight, according
     *  to the weights of its edge labels.  VLABEL and ELABEL are the types of
     *  vertex and edge labels.  Assumes that H is a distance measure
     *  between vertices satisfying the two properties:
     *     a. H.dist(v, V1) <= shortest path from v to V1 for any v, and
     *     b. H.dist(v, w) <= H.dist(w, V1) + weight of edge (v, w), where
     *        v and w are any vertices in G.
     *
     *  As a side effect, sets the weight of vertex v to the weight of
     *  a minimal path from V0 to v, for each v in the returned path
     *  and for each v such that
     *       minimum path length from V0 to v + H.dist(v, V1)
     *           < minimum path length from V0 to V1.
     *  The final weights of other vertices are not defined.
     *
     *  This function has the same effect as the 6-argument version of
     *  shortestPath, but uses the .weight and .setWeight methods of
     *  the edges and vertices themselves to determine and set
     *  weights. If V1 is unreachable from V0, returns null and sets
     *  the minimum path weights of all reachable nodes.  The distance
     *  to a node unreachable from V0 is Double.POSITIVE_INFINITY. */
    public static
    <VLabel extends Weightable, ELabel extends Weighted>
    List<Graph<VLabel, ELabel>.Edge>
    shortestPath(Graph<VLabel, ELabel> G,
                 Graph<VLabel, ELabel>.Vertex V0,
                 Graph<VLabel, ELabel>.Vertex V1,
                 Distancer<? super VLabel> h) {
        return null;
        // FIX ME
    }

    /** Returns a distancer whose dist method always returns 0. */
    public static final Distancer<Object> ZERO_DISTANCER =
        new Distancer<Object>() {
            @Override
            public double dist(Object v0, Object v1) {
                return 0.0;
            }
        };
}
